import { NextResponse } from "next/server";
import { createSupabaseServerClient } from "@/lib/supabase/server";
import { memberUpsertSchema } from "@/lib/validators/member";
import { rateLimit } from "@/lib/rate-limit";
import type { NextRequest } from "next/server";

export async function GET() {
  const supabase = await createSupabaseServerClient();
  const { data, error } = await supabase.from("members").select("*").limit(100);
  if (error)
    return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ data });
}

export async function POST(request: NextRequest) {
  const rl = await rateLimit(request, "api:members:post");
  if (!rl.success)
    return NextResponse.json({ error: "Too Many Requests" }, { status: 429 });
  const body = await request.json().catch(() => ({}));
  const parsed = memberUpsertSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.flatten() },
      { status: 400 },
    );
  }
  const supabase = await createSupabaseServerClient();
  const { data, error } = await supabase
    .from("members")
    .insert({
      personal_info: parsed.data.personal_info,
      contact_info: parsed.data.contact_info,
      address_info: parsed.data.address_info,
      membership_info: parsed.data.membership_info,
      metadata: parsed.data.metadata,
      is_active: parsed.data.is_active,
      is_deceased: parsed.data.is_deceased,
    })
    .select("*")
    .single();
  if (error)
    return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ data }, { status: 201 });
}
