export default function Home() {
  return (
    <div>
      <h1>Welcome to the landing page!</h1>
    </div>
  );
}

