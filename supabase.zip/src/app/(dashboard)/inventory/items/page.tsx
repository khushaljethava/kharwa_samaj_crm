import Link from "next/link";
import { createSupabaseServerClient } from "@/lib/supabase/server";

async function fetchItems() {
  const supabase = await createSupabaseServerClient();
  const { data, error } = await supabase
    .from("inventory_items")
    .select("id, sku, item_details")
    .limit(100);
  if (error) throw new Error(error.message);
  return data ?? [];
}

export default async function ItemsPage() {
  const items = await fetchItems();
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-semibold">Inventory Items</h1>
        <Link
          href="/inventory/items/new"
          className="px-3 py-2 rounded bg-black text-white dark:bg-white dark:text-black"
        >
          Add Item
        </Link>
      </div>
      <div className="overflow-x-auto rounded border">
        <table className="min-w-full text-sm">
          <thead>
            <tr className="bg-muted text-left">
              <th className="p-2">SKU</th>
              <th className="p-2">Name</th>
            </tr>
          </thead>
          <tbody>
            {items.map(
              (i: {
                id: string;
                sku: string;
                item_details: Record<string, unknown> | null;
              }) => {
                const details = (i.item_details || {}) as Record<
                  string,
                  unknown
                >;
                return (
                  <tr key={i.id} className="border-t">
                    <td className="p-2">{i.sku}</td>
                    <td className="p-2">{(details.name as string) || "—"}</td>
                  </tr>
                );
              },
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
