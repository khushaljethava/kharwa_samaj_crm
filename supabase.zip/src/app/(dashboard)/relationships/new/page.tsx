"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

export default function NewRelationshipPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function onSubmit(formData: FormData) {
    setLoading(true);
    setError(null);
    const body = {
      member_1_id: String(formData.get("member_1_id") || ""),
      member_2_id: String(formData.get("member_2_id") || ""),
      relationship_type: String(formData.get("relationship_type") || ""),
      relationship_status: String(formData.get("relationship_status") || ""),
      start_date: String(formData.get("start_date") || ""),
      end_date: String(formData.get("end_date") || ""),
    };
    const res = await fetch("/api/relationships", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(body),
    });
    setLoading(false);
    if (res.ok) router.push("/relationships");
    else {
      const j = await res.json().catch(() => ({}));
      setError(j?.error ? JSON.stringify(j.error) : "Failed to create");
    }
  }

  return (
    <div className="space-y-6 max-w-xl">
      <h1 className="text-xl font-semibold">New Relationship</h1>
      <form action={onSubmit} className="space-y-4">
        <input name="member_1_id" placeholder="Member 1 ID" className="w-full rounded border px-3 py-2" required />
        <input name="member_2_id" placeholder="Member 2 ID" className="w-full rounded border px-3 py-2" required />
        <input name="relationship_type" placeholder="Type (e.g., spouse)" className="w-full rounded border px-3 py-2" required />
        <input name="relationship_status" placeholder="Status (optional)" className="w-full rounded border px-3 py-2" />
        <div className="grid grid-cols-2 gap-2">
          <input name="start_date" type="date" className="w-full rounded border px-3 py-2" />
          <input name="end_date" type="date" className="w-full rounded border px-3 py-2" />
        </div>
        {error && <p className="text-sm text-red-600">{error}</p>}
        <button disabled={loading} className="px-3 py-2 rounded bg-black text-white disabled:opacity-50">
          {loading ? "Saving..." : "Save"}
        </button>
      </form>
    </div>
  );
}


