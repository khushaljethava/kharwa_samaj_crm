import Link from "next/link";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { createSupabaseServerClient } from "@/lib/supabase/server";

async function fetchMembers() {
  const supabase = await createSupabaseServerClient();
  const { data, error } = await supabase
    .from("members")
    .select("id, member_code, personal_info")
    .order("created_at", { ascending: false })
    .limit(50);
  if (error) {
    if (error.message?.includes("Could not find the table")) return [];
    throw new Error(error.message);
  }
  return data ?? [];
}

export default async function MembersPage() {
  const members = await fetchMembers();
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-semibold">Members</h1>
        <Link
          href="/members/new"
          className="px-3 py-2 rounded bg-black text-white dark:bg-white dark:text-black"
        >
          Add Member
        </Link>
      </div>
      <div className="overflow-x-auto rounded border">
        <table className="min-w-full text-sm">
          <thead>
            <tr className="bg-muted text-left">
              <th className="p-2">Code</th>
              <th className="p-2">Name</th>
            </tr>
          </thead>
          <tbody>
            {members.map(
              (m: {
                id: string;
                member_code: string;
                personal_info: Record<string, unknown> | null;
              }) => {
                const pi = (m.personal_info || {}) as Record<string, unknown>;
                const name =
                  [
                    pi.first_name as string,
                    pi.middle_name as string,
                    pi.last_name as string,
                  ]
                    .filter(Boolean)
                    .join(" ") || "—";
                return (
                  <tr key={m.id} className="border-t">
                    <td className="p-2 align-top">{m.member_code}</td>
                    <td className="p-2 align-top">
                      <Link className="underline" href={`/members/${m.id}`}>
                        {name}
                      </Link>
                    </td>
                  </tr>
                );
              },
            )}
            {members.length === 0 && (
              <tr>
                <td className="p-3" colSpan={2}>
                  No members
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
