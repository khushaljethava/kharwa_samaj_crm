"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

export default function NewMemberPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);

  async function onSubmit(formData: FormData) {
    setLoading(true);
    const body = {
      personal_info: { first_name: formData.get("first_name") },
      contact_info: { phone_primary: formData.get("phone") },
    };
    const res = await fetch("/api/members", {
      method: "POST",
      body: JSON.stringify(body),
    });
    setLoading(false);
    if (res.ok) router.push("/members");
    else alert("Failed to create member");
  }

  return (
    <div className="space-y-6 max-w-xl">
      <h1 className="text-xl font-semibold">New Member</h1>
      <form action={onSubmit} className="space-y-4">
        <input
          name="first_name"
          placeholder="First name"
          className="w-full rounded border px-3 py-2"
        />
        <input
          name="phone"
          placeholder="Phone"
          className="w-full rounded border px-3 py-2"
        />
        <button
          disabled={loading}
          className="px-3 py-2 rounded bg-black text-white disabled:opacity-50"
        >
          {loading ? "Saving..." : "Save"}
        </button>
      </form>
    </div>
  );
}
