import Link from "next/link";
import { notFound } from "next/navigation";
import { createSupabaseServerClient } from "@/lib/supabase/server";

async function fetchMember(id: string) {
  const supabase = await createSupabaseServerClient();
  const { data, error } = await supabase
    .from("members")
    .select("id, member_code, personal_info, contact_info, address_info, membership_info")
    .eq("id", id)
    .single();
  if (error) return null;
  return data as {
    id: string;
    member_code: string | null;
    personal_info: Record<string, unknown> | null;
    contact_info: Record<string, unknown> | null;
    address_info: Record<string, unknown> | null;
    membership_info: Record<string, unknown> | null;
  };
}

export default async function MemberDetailPage(props: { params: Promise<{ id: string }> }) {
  const { id } = await props.params;
  const member = await fetchMember(id);
  if (!member) return notFound();
  const pi = (member.personal_info || {}) as Record<string, unknown>;
  const name = [pi.first_name as string, pi.middle_name as string, pi.last_name as string]
    .filter(Boolean)
    .join(" ") || "—";
  return (
    <div className="space-y-6 max-w-3xl">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">{name}</h1>
        <Link href="/members" className="text-sm underline">Back</Link>
      </div>
      <div className="grid gap-4 md:grid-cols-2">
        <div className="rounded border p-4">
          <h2 className="font-semibold mb-2">Member</h2>
          <div className="text-sm">Code: {member.member_code}</div>
        </div>
        <div className="rounded border p-4">
          <h2 className="font-semibold mb-2">Contact</h2>
          <pre className="text-xs whitespace-pre-wrap">{JSON.stringify(member.contact_info, null, 2)}</pre>
        </div>
        <div className="rounded border p-4">
          <h2 className="font-semibold mb-2">Address</h2>
          <pre className="text-xs whitespace-pre-wrap">{JSON.stringify(member.address_info, null, 2)}</pre>
        </div>
        <div className="rounded border p-4">
          <h2 className="font-semibold mb-2">Membership</h2>
          <pre className="text-xs whitespace-pre-wrap">{JSON.stringify(member.membership_info, null, 2)}</pre>
        </div>
      </div>
    </div>
  );
}


