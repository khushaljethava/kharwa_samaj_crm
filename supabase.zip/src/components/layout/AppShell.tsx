"use client";
import Link from "next/link";
import { cn } from "@/lib/utils/cn";
import { useState } from "react";
import { createSupabaseBrowserClient } from "@/lib/supabase/client";

export function AppShell({ children }: { children: React.ReactNode }) {
  const [signingOut, setSigningOut] = useState(false);
  const supabase = createSupabaseBrowserClient();

  async function onSignOut() {
    setSigningOut(true);
    await supabase.auth.signOut();
    window.location.href = "/login";
  }

  // Ensure the current user's role is synced with allowlist on first render
  if (typeof window !== "undefined") {
    // fire and forget; ignore failures
    fetch("/api/admin/sync-role", { method: "POST" }).catch(() => {});
  }

  return (
    <div className="min-h-screen grid grid-cols-1 lg:grid-cols-[240px_1fr]">
      <aside className="border-r bg-background/50 p-4 hidden lg:block">
        <nav className="space-y-2 text-sm">
          <Link
            href="/dashboard"
            className={cn("block rounded px-2 py-1 hover:bg-muted")}
          >
            Dashboard
          </Link>
          <Link
            href="/members"
            className={cn("block rounded px-2 py-1 hover:bg-muted")}
          >
            Members
          </Link>
          <Link
            href="/inventory/items"
            className={cn("block rounded px-2 py-1 hover:bg-muted")}
          >
            Inventory
          </Link>
          <Link
            href="/rent/collections"
            className={cn("block rounded px-2 py-1 hover:bg-muted")}
          >
            Rent
          </Link>
          <Link
            href="/membership/plans"
            className={cn("block rounded px-2 py-1 hover:bg-muted")}
          >
            Membership
          </Link>
          <Link
            href="/membership/payments"
            className={cn("block rounded px-2 py-1 hover:bg-muted")}
          >
            Membership Payments
          </Link>
        </nav>
      </aside>
      <main className="p-4">
        <div className="flex items-center justify-end pb-4">
          <button
            onClick={onSignOut}
            disabled={signingOut}
            className="text-sm rounded px-3 py-1.5 border hover:bg-muted disabled:opacity-50"
            aria-label="Sign out"
          >
            {signingOut ? "Signing out…" : "Sign out"}
          </button>
        </div>
        {children}
      </main>
    </div>
  );
}
